# plugin.video.pelisalacarta.it

This is Kodi plugin Pelisalacarta version 4.0.3 with italian channels repack  
