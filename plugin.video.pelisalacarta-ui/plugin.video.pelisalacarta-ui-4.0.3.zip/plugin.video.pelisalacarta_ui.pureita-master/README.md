# plugin.video.pelisalacarta_ui.pureita
Italian version of pelisalacarta-ui v4.0.3,
and only with Italian channels.
Fixed the new options with Italian channels,
translated the tweaked "buscador general" in Italian.
The downloadable .zip can be installed directly into Kodi.
It is suggested to remove any other pelisalacarta version first, restart Kodi and then install this.
Removed channels not in italian (sorry but that also makes the plugin lighter)
Removed adult options and contents, these can be added easily by yourself!

Many thanks to jesus (pelisalacarta founder), dentaku65, zanzibar1982, robalo and DrZ3ro for all the good work.

Also refer to forum: http://www.mimediacenter.info/foro/viewtopic.php?f=22&t=6821
